package com.divya;

import java.util.*;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringWriter;

import com.covid.Corona;
import com.covid.Coviddata;
import com.covid.Latestdata;
import com.covid.PopulationCompare;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.httpclient.*;
import org.apache.commons.httpclient.methods.GetMethod;



public class CovidAPI {
    private static int codeIndex;
    private String codeInput;


    public static void main(String[] args) {
        HttpClient client = new HttpClient();
        // Create a method instance.
        GetMethod method = new GetMethod("https://corona-api.com/countries");

        try {
            // Execute the method.
            int statusCode = client.executeMethod(method);

            if (statusCode != HttpStatus.SC_OK) {
                System.err.println("Method failed: " + method.getStatusLine());
            }

            InputStreamReader isr = new InputStreamReader(method.getResponseBodyAsStream(), "UTF-8");
            StringWriter sw = new StringWriter();
            int c;
            while ((c = isr.read()) != -1) {
                sw.write(c);

            }
            sw.close();
            //System.out.println("Printing");
            //System.out.println(sw.toString());
            isr.close();

            // Read the response body.
            byte[] responseBody = method.getResponseBody();

            ArrayList<Corona> coronaData = new ArrayList<Corona>();

            Corona cObj = new Corona();
            ObjectMapper objectMapper = new ObjectMapper();


            Coviddata data = objectMapper.readValue(sw.toString(), Coviddata.class);
            List<Corona> coronaList = Arrays.asList(data.getData());
            /*System.out.println(data.getData().length);
            System.out.println("Cache:" + data.is_cacheHit());*/

            Collections.sort(coronaList, new PopulationCompare());
            HashMap countryMap = new HashMap();

            for (int i = 0; i < coronaList.size(); i++) {
                Corona cr = coronaList.get(i);
                countryMap.put(cr.getCode(), cr);
                System.out.println("Name: " + cr.getName() + "   Population: " + cr.getPopulation());
            }

            String codeInput = "";
            while (true) {
                System.out.println(codeInput);
                Scanner input = new Scanner(System.in);
                System.out.println("Please enter the country code:");
                codeInput = input.nextLine();
                if (codeInput.equals("exit")) {
                    break;
                }

                Corona countryData = (Corona) countryMap.get(codeInput);
                System.out.println(countryData.toString());
            }
            // Deal with the response.
            // Use caution: ensure correct character encoding and is not binary data

        } catch (HttpException e) {
            System.err.println("Fatal protocol violation: " + e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("Fatal transport error: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // Release the connection.
            method.releaseConnection();
        }
    }
}